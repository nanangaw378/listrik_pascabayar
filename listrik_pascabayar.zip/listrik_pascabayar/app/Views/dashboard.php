<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h2 class="mt-5">Selamat datang, <?= session('username') ?></h2>
    <p>Level: <?= session('id_level') == 1 ? 'Admin' : 'User' ?></p>
    <a href="<?= base_url('pelanggan') ?>" class="btn btn-success">Kelola Pelanggan</a>
<a href="<?= base_url('auth/logout') ?>" class="btn btn-danger">Logout</a>
<a href="<?= base_url('penggunaan') ?>" class="btn btn-info">Kelola Penggunaan</a>
<a href="<?= base_url('tagihan') ?>" class="btn btn-warning">Lihat Tagihan</a>

</body>
</html>
