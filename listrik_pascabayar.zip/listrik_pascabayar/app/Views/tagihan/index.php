<!DOCTYPE html>
<html>
<head>
    <title>Data Tagihan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h1 class="mt-4">Data Tagihan Listrik</h1>
    <table class="table table-striped">
        <tr>
            <th>ID</th><th>Pelanggan</th><th>Bulan</th><th>Jumlah Meter</th><th>Status</th>
        </tr>
        <?php foreach ($tagihan as $row): ?>
        <tr>
            <td><?= $row['id_tagihan'] ?></td>
            <td><?= $row['id_pelanggan'] ?></td>
            <td><?= $row['bulan'] ?></td>
            <td><?= $row['jumlah_meter'] ?></td>
            <td><?= $row['status'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
