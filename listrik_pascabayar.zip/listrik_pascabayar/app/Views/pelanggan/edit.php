<!DOCTYPE html>
<html>
<head>
    <title>Edit Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h1>Edit Pelanggan</h1>
    <form method="post" action="<?= base_url('pelanggan/update/' . $pelanggan['id_pelanggan']) ?>">
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama_pelanggan" value="<?= $pelanggan['nama_pelanggan'] ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Alamat</label>
            <input type="text" name="alamat" value="<?= $pelanggan['alamat'] ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Daya</label>
            <input type="number" name="daya" value="<?= $pelanggan['daya'] ?>" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</body>
</html>
