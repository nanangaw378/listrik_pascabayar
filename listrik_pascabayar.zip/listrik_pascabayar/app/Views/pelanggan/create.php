<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h1>Tambah Pelanggan</h1>
    <form method="post" action="<?= base_url('pelanggan/store') ?>">
        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Nama Pelanggan</label>
            <input type="text" name="nama_pelanggan" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label>Tarif</label>
            <select name="id_tarif" class="form-control" required>
                <option value="">-- Pilih Tarif --</option>
                <?php foreach ($tarif as $t): ?>
                    <option value="<?= $t['id_tarif'] ?>">
                        <?= $t['daya'] ?> VA - Rp <?= number_format($t['tarifperkwh']) ?>/kWh
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</body>
</html>
