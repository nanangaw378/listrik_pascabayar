<!DOCTYPE html>
<html>
<head>
    <title>Tambah Penggunaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container">
    <h1 class="mt-4">Tambah Data Penggunaan</h1>
    <form method="post" action="<?= base_url('penggunaan/store') ?>">
        <div class="mb-3">
            <label>Pilih Pelanggan</label>
            <select name="id_pelanggan" class="form-control">
                <?php foreach ($pelanggan as $p): ?>
                <option value="<?= $p['id_pelanggan'] ?>"><?= $p['nama_pelanggan'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Bulan</label>
            <input type="text" name="bulan" class="form-control">
        </div>
        <div class="mb-3">
            <label>Meter Awal</label>
            <input type="number" name="meter_awal" class="form-control">
        </div>
        <div class="mb-3">
            <label>Meter Akhir</label>
            <input type="number" name="meter_akhir" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</body>
</html>
