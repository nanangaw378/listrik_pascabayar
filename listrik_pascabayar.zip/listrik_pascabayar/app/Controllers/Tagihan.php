<?php

namespace App\Controllers;

use App\Models\TagihanModel;
use App\Models\PenggunaanModel;

class Tagihan extends BaseController
{
    protected $tagihan;

    public function __construct()
    {
        $this->tagihan = new TagihanModel();
    }

    public function index()
    {
        $data['tagihan'] = $this->tagihan->getTagihanWithPenggunaan();
        return view('tagihan/index', $data);
    }
}
