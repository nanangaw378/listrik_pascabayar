<?php

namespace App\Controllers;

use App\Models\PenggunaanModel;
use App\Models\PelangganModel;

class Penggunaan extends BaseController
{
    protected $penggunaan;
    protected $pelanggan;

    public function __construct()
    {
        $this->penggunaan = new PenggunaanModel();
        $this->pelanggan = new PelangganModel();
    }

    public function index()
    {
        $data['penggunaan'] = $this->penggunaan->getPenggunaanWithPelanggan();
        return view('penggunaan/index', $data);
    }

    public function create()
    {
        $data['pelanggan'] = $this->pelanggan->findAll();
        return view('penggunaan/create', $data);
    }

    public function store()
    {
        $this->penggunaan->save([
            'id_pelanggan' => $this->request->getPost('id_pelanggan'),
            'bulan' => $this->request->getPost('bulan'),
            'meter_awal' => $this->request->getPost('meter_awal'),
            'meter_akhir' => $this->request->getPost('meter_akhir'),
        ]);

        return redirect()->to('/penggunaan');
    }

    public function delete($id)
    {
        // ✅ Tambah pengecekan supaya tidak error delete semua data
        if ($id) {
            $this->penggunaan->where('id_penggunaan', $id)->delete();
        }

        return redirect()->to('/penggunaan');
    }
}
