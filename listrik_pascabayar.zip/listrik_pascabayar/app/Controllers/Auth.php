<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\LevelModel;

class Auth extends BaseController
{
    public function index()
    {
        return view('auth/login');
    }

    public function login()
    {
        $session = session();
        $model = new UserModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $model->where('username', $username)->first();

        if ($user) {
            if ($user['password'] == $password) {
                $session->set('logged_in', true);
                $session->set('username', $user['username']);
                $session->set('id_level', $user['id_level']);

                return redirect()->to('/dashboard');
            } else {
                return redirect()->to('/auth')->with('error', 'Password salah');
            }
        } else {
            return redirect()->to('/auth')->with('error', 'Username tidak ditemukan');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth');
    }

    public function dashboard()
    {
        return view('dashboard');
    }
}