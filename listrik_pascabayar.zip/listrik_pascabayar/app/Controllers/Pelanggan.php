<?php

namespace App\Controllers;

use App\Models\PelangganModel;
use App\Models\TarifModel;

class Pelanggan extends BaseController
{
    protected $pelanggan;

    public function __construct()
    {
        $this->pelanggan = new PelangganModel();
    }

    public function index()
    {
        $data['pelanggan'] = $this->pelanggan
            ->select('pelanggan.*, tarif.daya AS daya_tarif, tarif.tarifperkwh')
            ->join('tarif', 'pelanggan.id_tarif = tarif.id_tarif', 'left') // LEFT JOIN agar data tetap muncul meski id_tarif NULL
            ->findAll();
        return view('pelanggan/index', $data);
    }

    public function create()
    {
        $tarif = new TarifModel();
        $data['tarif'] = $tarif->findAll();
        return view('pelanggan/create', $data);
    }

    public function store()
    {
        $this->pelanggan->save([
            'nama_pelanggan' => $this->request->getPost('nama_pelanggan'),
            'alamat' => $this->request->getPost('alamat'),
            'id_tarif' => $this->request->getPost('id_tarif'),
        ]);

        return redirect()->to('/pelanggan')->with('success', 'Data berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $tarif = new TarifModel();
        $data['tarif'] = $tarif->findAll();
        $data['pelanggan'] = $this->pelanggan->find($id);
        return view('pelanggan/edit', $data);
    }

    public function update($id)
    {
        $this->pelanggan->update($id, [
            'nama_pelanggan' => $this->request->getPost('nama_pelanggan'),
            'alamat' => $this->request->getPost('alamat'),
            'id_tarif' => $this->request->getPost('id_tarif'),
        ]);

        return redirect()->to('/pelanggan')->with('success', 'Data berhasil diupdate.');
    }

    public function delete($id = null)
    {
        if ($id) {
            $this->pelanggan->where('id_pelanggan', $id)->delete();
            return redirect()->to('/pelanggan')->with('success', 'Data berhasil dihapus.');
        } else {
            return redirect()->to('/pelanggan')->with('error', 'ID tidak valid.');
        }
    }
}
