<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// ✅ ROUTE AUTH
$routes->get('/auth', 'Auth::index');
$routes->post('/auth/login', 'Auth::login');
$routes->get('/auth/logout', 'Auth::logout');
$routes->get('/dashboard', 'Auth::dashboard', ['filter' => 'auth']);

// ✅ ROUTE CRUD PELANGGAN
$routes->get('/pelanggan', 'Pelanggan::index', ['filter' => 'auth']);
$routes->get('/pelanggan/create', 'Pelanggan::create', ['filter' => 'auth']);
$routes->post('/pelanggan/store', 'Pelanggan::store', ['filter' => 'auth']);
$routes->get('/pelanggan/edit/(:num)', 'Pelanggan::edit/$1', ['filter' => 'auth']);
$routes->post('/pelanggan/update/(:num)', 'Pelanggan::update/$1', ['filter' => 'auth']);
$routes->get('/pelanggan/delete/(:num)', 'Pelanggan::delete/$1', ['filter' => 'auth']);

// ✅ ROUTE CRUD PENGGUNAAN
$routes->get('/penggunaan', 'Penggunaan::index', ['filter' => 'auth']);
$routes->get('/penggunaan/create', 'Penggunaan::create', ['filter' => 'auth']);
$routes->post('/penggunaan/store', 'Penggunaan::store', ['filter' => 'auth']);
$routes->get('/penggunaan/delete/(:num)', 'Penggunaan::delete/$1', ['filter' => 'auth']);

// ✅ ROUTE TAGIHAN
$routes->get('/tagihan', 'Tagihan::index', ['filter' => 'auth']);
