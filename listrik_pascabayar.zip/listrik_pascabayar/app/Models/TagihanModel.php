<?php

namespace App\Models;

use CodeIgniter\Model;

class TagihanModel extends Model
{
    protected $table = 'tagihan';
    protected $primaryKey = 'id_tagihan';
    protected $allowedFields = ['id_penggunaan', 'jumlah_meter', 'status'];

    public function getTagihanWithPenggunaan()
    {
        return $this->select('tagihan.*, penggunaan.bulan, penggunaan.id_pelanggan')
                    ->join('penggunaan', 'tagihan.id_penggunaan = penggunaan.id_penggunaan')
                    ->findAll();
    }
}
