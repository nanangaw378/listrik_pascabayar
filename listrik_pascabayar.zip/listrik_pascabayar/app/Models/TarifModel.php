<?php

namespace App\Models;

use CodeIgniter\Model;

class TarifModel extends Model
{
    protected $table = 'tarif';
    protected $primaryKey = 'id_tarif';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['daya', 'tarifperkwh'];
}
