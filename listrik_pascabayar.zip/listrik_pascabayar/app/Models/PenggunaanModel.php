<?php

namespace App\Models;

use CodeIgniter\Model;

class PenggunaanModel extends Model
{
    protected $table = 'penggunaan';
    protected $primaryKey = 'id_penggunaan';
    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_pelanggan', 'bulan', 'meter_awal', 'meter_akhir'];

    public function getPenggunaanWithPelanggan()
    {
        return $this->select('penggunaan.*, pelanggan.nama_pelanggan')
                    ->join('pelanggan', 'penggunaan.id_pelanggan = pelanggan.id_pelanggan')
                    ->findAll();
    }
}
